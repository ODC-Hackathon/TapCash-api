To run application :
1- You need to setup Xammp or Wamp 
2- You need to install composer 

3- git clone the repository
4- go into folder u install 
5- open terminal then
	composer install
	php artisan key:generate
	php artisan migrate
	php aritsna serve (after this application is running)

6- to understant APIS
	visit this link
	https://docs.google.com/spreadsheets/d/1_7a2y5Ws2GoTmU_JFYvx3mEWcEOQYdGp36d6d6f5qQg/edit?usp=sharing