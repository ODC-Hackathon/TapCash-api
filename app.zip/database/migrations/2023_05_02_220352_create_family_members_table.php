<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('family_members', function (Blueprint $table) {
            $table->id();
            $table->string('phone_number',11)->unique();
            $table->string('user_name')->unique();
            $table->foreignId('sponsor_id')->constrained('users','id')->cascadeOnDelete();
            $table->string('name');
            // $table->decimal('percentage',5,2);
            // $table->decimal('total_amount',10,2)->nullable();
            $table->string('pincode');
            $table->date("amount_added");
            $table->decimal("allowed_money")->default(0);
            $table->decimal("spent_money")->default(0);
            // $table->unique(['user_name','sponsor_id']);
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('family_members');
    }
};
